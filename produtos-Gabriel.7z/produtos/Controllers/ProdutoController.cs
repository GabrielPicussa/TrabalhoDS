using Microsoft.AspNetCore.Mvc;
using produto.Models;

namespace produto.Controllers
{
    public class ProdutoController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var produtos = new List<Produto>{
                new Produto{
                    Id = 1,
                    Nome = "Garrafa térmica",
                    Valor = 50.00m,
                    Cat = "Utensílio",
                    Desc = "Garrafa térmica stanley 500ml, diretamente importada dos EUA"
                },
                new Produto{
                    Id = 2,
                    Nome = "Mochila",
                    Valor = 700.00m,
                    Cat = "Utensílio",
                    Desc = "Mochila de acampamento verde camuflada 40L"
                }
            };


            return View(produtos);
        }
    }
}
