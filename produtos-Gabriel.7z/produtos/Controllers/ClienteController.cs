using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class clienteController : Controller
    {


        public IActionResult Index()
        {

            
            var cliente = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Thalioris Vespera",
                    CPF = "321.654.987-00",
                    Endereço = "Rua dos Estrelados, 456, Residencial Eclipse, Vila das Nuvens, Rio de Janeiro - RJ, 65432-109",
                    Telefone = "(21) 98765-4321",
                    Email = "thalioris.vespera@stellarhub.com"

                },
                new Cliente{
                    Id = 2,
                    Nome = "Zaraelith Anovarian",
                    CPF = "987.654.321-00",
                    Endereço = "Avenida Luminares, 789, Torre Celestial, Bairro dos Arcanos, Campinas - SP, 98765-432",
                    Telefone = "(19) 91234-5678",
                    Email = "zaraelith.anovarian@cosmicmail.com"

                }
            };


            return View(cliente);
        }
    }
}