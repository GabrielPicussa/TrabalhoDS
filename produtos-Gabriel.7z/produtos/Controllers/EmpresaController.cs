using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class empresaController : Controller
    {


        public IActionResult Index()
        {

            
            var empresa = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Nome = "Siam Souvenirs Co. Ltd.",
                    Endereço = "Rua dos Tempos Antigos, 789, Centro Cultural Siam, Loja 24, Bairro das Tradições, Belo Horizonte - MG, 34567-890",
                    Desconto = "10% em compras acima de R$ 100,00",
                    RegimeFiscal = "Simples Nacional",
                    CNPJ = "34.567.890/0001-23"

                },
                new Empresa{
                    Id = 2, 
                    Nome = "Bergland Ausrüstung GmbH",
                    Endereço = "Avenida dos Pioneiros, 2345, Parque das Montanhas, Sala 101, Curitiba - PR, 67890-123",
                    Desconto = "12% em todas as compras acima de R$ 200,00",
                    RegimeFiscal = "Simples Nacional",
                    CNPJ = "45.678.901/0001-45"

                   
                }
            };


            return View(empresa);
        }
    }
}