namespace empresa.Models{

    class Empresa{

        public int Id { get; set; }
        public string Nome{ get; set; } = "";
        public string Endereço {get; set; } = "";
        public string Desconto  {get; set;} = "";
        public string RegimeFiscal { get; set; } = "";
        public string CNPJ  { get; set; } = "";

    }


}